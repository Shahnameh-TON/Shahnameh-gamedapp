module.exports = {
	dbconnection:'mongodb://localhost:27017/khabat',
	//dbconnection:'mongodb://Y024dEg8R1NW:Qia8HdCi2o8IRJzlNi@194.195.115.112:32093/RcFaikOsjce',
}